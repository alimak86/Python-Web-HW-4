from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import mimetypes
import pathlib
import socket
import threading
import json
from datetime import datetime
import os

PORT = 3000 ## http port
UDP_IP = '127.0.0.1' ## for sockets
UDP_PORT = 5000  ## for the sockets
BLOCK_SIZE = 1024 ## size of the data to read
FILE = "./storage/data.json"

class Server:

    def __init__(self, ip = '127.0.0.1', port = 5000):
        self.ip = ip
        self.port = port
        

    def savetofile(self,filename,record):
        if os.path.exists(filename):
                with open(filename,"a") as fh:
                    json.dump(record,fh)
        else:
            with open(filename,"w") as fh:
                json.dump(record,fh)

    def __call__(self): ## in order to run in thread
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server = self.ip, self.port
        sock.bind(server)
        try:
            while True:
                data, address = sock.recvfrom(BLOCK_SIZE)
                print(f'Received data: {data.decode()} from: {address}')
                time = str(datetime.now())
                print("time received: ", time)
                data_parse = urllib.parse.unquote_plus(data.decode())
                print(data_parse)
                data_dict = {key: value for key, value in [el.split('=') for el in data_parse.split('&')]}
                print(data_dict)
                record = {}
                record[time]= data_dict
                print(record)
                self.savetofile(FILE,record)

                # sock.sendto(data, address)
                # print(f'Send data: {data.decode()} to: {address}')

        except KeyboardInterrupt:
            print(f'Destroy server')
        finally:
            sock.close()

class Client:
    def __init__(self, udp_ip = '127.0.0.1', udp_port = 5000 ):
        self.ip = udp_ip
        self.port = udp_port

    def sendtoserver(self,data):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server = self.ip, self.port
        sock.sendto(data, server)
        print(f'Send data: {data.decode()} to socket server: {server}')
        sock.close()

class HttpHandler(BaseHTTPRequestHandler):

    client = Client(UDP_IP,UDP_PORT) ## do not know how to use constructor
    
    def do_POST(self):
        data = self.rfile.read(int(self.headers['Content-Length']))
        print(data)
        self.client.sendtoserver(data) ## send received data to socket server

        self.send_response(302)
        self.send_header('Location', '/')
        self.end_headers()

    def do_GET(self):
        pr_url = urllib.parse.urlparse(self.path)
        #print(pr_url.path)
        if pr_url.path == '/':
            self.send_html_file('index.html')
        elif pr_url.path == '/message':
            self.send_html_file('message.html')
        else:
            if pathlib.Path().joinpath(pr_url.path[1:]).exists():
                self.send_static()
            else:
                self.send_html_file('error.html', 404)

    def send_html_file(self, filename, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        with open(filename, 'rb') as fd:
            self.wfile.write(fd.read())

    def send_static(self):
        self.send_response(200)
        mt = mimetypes.guess_type(self.path)
        if mt:
            self.send_header("Content-type", mt[0])
        else:
            self.send_header("Content-type", 'text/plain')
        self.end_headers()
        with open(f'.{self.path}', 'rb') as file:
            self.wfile.write(file.read())

def run(server_class=HTTPServer, handler_class=HttpHandler):
    server_address = ('', PORT)
    http = server_class(server_address, handler_class)
    try:
        http.serve_forever()
    except KeyboardInterrupt:
        http.server_close()


if __name__ == '__main__':

    http_handler = HttpHandler
    http_server = threading.Thread(target = run, args = (HTTPServer, http_handler), name = "http server")
    http_server.start()

    server = Server(UDP_IP, UDP_PORT)
    socket_server = threading.Thread(target = server, name  = "socket server")
    socket_server.start()

    http_server.join()
    socket_server.join()
    print("completed")
